;(function($, window, document, undefined) {
	let $win = $(window);
	let $doc = $(document);

	$doc.ready(function() {
		$('.nav-trigger').on('click', function(event) {
			$(this).toggleClass('active');
			
			$('.wrapper').toggleClass('nav-open');
			
			event.preventDefault();
		});

		$('.form-quote').on('change', '.product-select', function() {
			let selectedIndex = $(this).find(':selected').index()
			let qtty = '960'
			if(selectedIndex % 2 !== 0) {
				qtty = '480'
			}

			$(this).closest('.form-row-has-cols').find('.form-info em').text(qtty)
		})

		$('#add-row').on('click', function(event) {
			let rows = document.getElementsByClassName('form-row-has-cols');
			let parent = $(this).parent();
			let clone = rows[rows.length-1].cloneNode(true);
			//Label
			let index = rows.length + 1
			$(clone).find('.form-col-item label').attr('for', `item${index}`)
			$(clone).find('.form-col-item select').attr('name', `item${index}`)
			$(clone).find('.form-col-item select').attr('id', `item${index}`)

			$(clone).find('.form-col-qtty label').attr('for', `item${index}`)
			$(clone).find('.form-col-qtty input').attr('name', `item${index}`)
			$(clone).find('.form-col-qtty input').attr('id', `item${index}`)
			$(clone).find('.form-col-qtty .form-info em').text('960')
			$(clone).insertBefore(parent)
		})
	});

	$win.on('load', function() {
		$('.slider .slides').slick({
			dots: true,
			arrows: false,
			fade: true,
		})
	});
})(jQuery, window, document);
