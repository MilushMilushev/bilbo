<?php
error_reporting(E_ALL ^ E_WARNING); 
if(isset($_POST))
{
	$text="";
	$index=1;
	while(true)
	{
		if(empty($_POST['item'.$index]))
		{
			break;
		}
		$itemName = $_POST['item'.$index];
		$itemQtty=$_POST['qtty'.$index];
		$index++;
		$text=$text."Продукт: ".$itemName."\r\nКоличество: ".$itemQtty. "\r\n\r\n";
	}

	if(!empty($_POST['postCode'])) {
		$text=$text."Пощенски код: ".$_POST['postCode']."\r\n";
	}

	if(!empty($_POST['country'])) {
		$text=$text."Държава: ".$_POST['country']."\r\n";
	}

	if(!empty($_POST['shippingPreferences'])) {
		$text=$text."Предпочитан транспорт: ".$_POST['shippingPreferences']."\r\n";
	}
	if (!empty($_POST['comment'])) {
		$text=$text."Коментар: ".$_POST['comment']."\r\n";
	}
	
	if (!empty($_POST['companyName'])) {
		$text=$text."Фирма: ".$_POST['companyName']."\r\n";
	}
	if (!empty($_POST['contactPerson'])) {
		$text=$text."Човек за връзка: ".$_POST['contactPerson']."\r\n";
	}
	if (!empty($_POST['email'])) {
		$text=$text."Email: ".$_POST['email']."\r\n";
	}
	if (!empty($_POST['phone'])) {
		$text=$text."Телефон: ".$_POST['phone']."\r\n";
	}
	
	// mail('info@bilbohoney.eu,emil@bilbohoney.eu', 'Quote request bilbohoney.eu', $text);

	// $headers =  'MIME-Version: 1.0' . "\r\n"; 
	// $headers .= 'From: Your name <info@address.com>' . "\r\n";
	// $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
	mail('lort@abv.bg', 'Quote request bilbohoney.eu', $text);
}
?>

<?php include "ssi-header.shtml"; ?>

<section class="intro intro-contact">
	<div class="shell">
		<div class="intro-body">
			<div class="intro-content">
				<h1 class="title-primary">Success!</h1>
			</div><!-- /.intro-content -->
		</div><!-- /.intro-body -->
	</div><!-- /.shell -->	
</section><!-- /.intro -->

<section class="section section-secondary">
	<div class="shell shell-secondary">
		<h2 class="title-secondary">Thank you for your request!</h2>

		<h4>We will respond to you shortly!</h4>
	</div><!-- /.shell -->
</section><!-- /.section -->

<?php include "ssi-footer.shtml"; ?>
